<?php
$valor = "ola";

$valor2 = sprintf("$valor %a", "aaaaaaaaaaaa");

printf ($valor2);