<?php
include("conexao.php");
$id = $_GET['id'];

$my = mysql_query("DELETE FROM produtos WHERE id ='$id' ") or die(mysql_error());

if($my){
	echo '<script>alert("Produto deletado com sucesso");location.href="tudo.php"</script>';
}else{
	echo '<script>alert("Erro ao deletar produto");location.href="tudo.php"</script>';
}


