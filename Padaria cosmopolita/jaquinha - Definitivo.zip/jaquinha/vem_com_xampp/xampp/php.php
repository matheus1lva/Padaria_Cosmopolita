<?php
	echo "OK";
	exit;
?>
NOK
