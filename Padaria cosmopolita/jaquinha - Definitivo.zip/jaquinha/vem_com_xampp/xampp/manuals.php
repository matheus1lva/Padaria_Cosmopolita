<?php
	include "langsettings.php";
?>
<html>
	<head>
		<meta name="author" content="Kai Oswald Seidler">
		<link href="xampp.css" rel="stylesheet" type="text/css">
		<title></title>
	</head>

	<body>
		&nbsp;<p>
		<h1><?php echo $TEXT['manuals-head']; ?></h1>

		<?php echo $TEXT['manuals-text1']; ?>
		<?php echo $TEXT['manuals-list1']; ?>
		<?php echo $TEXT['manuals-text2']; ?>
		<?php echo $TEXT['manuals-list2']; ?>
		<?php echo $TEXT['manuals-text3']; ?>
	</body>
</html>
