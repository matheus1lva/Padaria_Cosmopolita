<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Sistema De Gerenciamento Padaria</title>


	<script type="text/javascript" src=""></script>
    <style type="text/css">
	body{

	}
		 a{
		
			text-decoration:none;
			color:#000;
			font:20px Tahoma, Geneva, sans-serif;
			font-weight:bolder;
			display:block;
			
		}
		a:hover{
			text-decoration:underline;
		}
		
		#tudo{
				margin:50px auto;
				border:1px solid #333;
				background-color:#e1e1e1;
				padding:8px;
				width:500px;
				
		}
	</style>
    
    
</head>

<body>
<div id="tudo">
    <a href="inserir.php">Inserir Produto</a><br />
    <a href="tudo.php">Ver Produtos</a><br />
<br />

    <a href="backup/index.php">Fazer Backup</a>
</div>

</body>
</html>
